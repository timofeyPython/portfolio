import { Route, Routes } from 'react-router-dom';
import { PrivateRoute } from '../components/Route/PrivateRoute';

 
import { AuthPage } from '../views/AuthPage'
import { Main } from '../pages/MainPage';

 export function useRoutes() { 
    return(
            <Routes>
                <Route path='/login' element={<AuthPage/>}/>
                <Route element={<PrivateRoute />}>
                    <Route path='/main' element={<Main />}/>
                </Route>
            </Routes> 
    )
}

 
 