import { useEffect, useState } from "react"
import './main.scss'

export function MainComponent() {
    const initalState: Array<{id: string, name: string}> = []
    const [data, setData] = useState(initalState)
    const {val, changeInput} = useInput('')
    const [arrayFiltred, setArrayFiltred] = useState(initalState)

    const filterArray = (event: any) => {
        changeInput(event)
 
        if (event.nativeEvent.inputType === 'deleteContentBackward') {
            const filtredArray = arrayFiltred.filter((entry)=> entry.name.includes(event.target.value))
            setData(filtredArray)
          
        } else {
            const array = data.filter((entry)=> entry.name.includes(event.target.value))
            setData(array)
        }
    
        
    }
    const loadData = (()=> {
        try {
            fetch('http://jsonplaceholder.typicode.com/users')
            .then(res=> res.json())
            .then(data=> {
                setData(data)
                setArrayFiltred(data)
            })
        } catch (e) {
            console.log(e)
        }
    })
 
    useEffect(()=> {
        loadData()
    }, [])
    return(
        <div className="home">
            <div>
                <h1>Main component</h1>
                <label htmlFor="input"> Фильтр</label>
                <input type="text" id="input" value={val} onChange={filterArray} />
            </div>
      
            <hr />
            <div>
                <div>
                    {data.map((entry, i)=> {
                        return(
                            <div key={i} className="block">
                                <h2>id: {entry.id}</h2>
                                <h2>name: {entry.name}</h2>
                                <hr/>
                            </div>
                     
                        )
                    })}
                </div>
            </div>
         
        </div>

    )
}


function useInput(value: string) {
    const [val, changeValue] = useState(value)

    function changeInput(event: {target: {value: string}}) {
        changeValue(event.target.value)
    }

    return {val, changeInput}
}
