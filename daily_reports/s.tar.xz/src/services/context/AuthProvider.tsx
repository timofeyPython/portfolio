import { createContext, useState } from "react";
import type { AuthContextType } from '../../types/types'

export const AuthContext = createContext<AuthContextType>({
    isAuthenticated: false,
    setAuth: () => {},
 });


 export const AuthProvider = ({ children }: { children: JSX.Element }) => {
    const logic = true
    const [isAuthenticated, setAuth] = useState<boolean>(logic);
    return (
        <AuthContext.Provider value={{ isAuthenticated, setAuth }}>
            {children}
        </AuthContext.Provider>
    )
}